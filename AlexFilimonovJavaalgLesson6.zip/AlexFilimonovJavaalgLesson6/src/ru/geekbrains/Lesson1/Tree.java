package ru.geekbrains.Lesson1;

public class Tree {
    private TreeNode root;

    public TreeNoteNumber find(int id) {
        TreeNode current = root;
        while (current.treeNoteNumber.uid != id) {
            if (id < current.treeNoteNumber.uid)
                current = current.left;
            else
                current = current.right;
            if (current == null)
                return null;
        }
        return current.treeNoteNumber;
    }

    public void insert(TreeNoteNumber p) {
        TreeNode node = new TreeNode(p);
        if (root == null) {
            root = node;
        } else {
            TreeNode current = root;
            TreeNode parent;
            while (true) {
                parent = current;
                if (p.uid < current.treeNoteNumber.uid) {
                    current = current.left;
                    if (current == null) {
                        parent.left = node;
                        return;
                    }
                } else {
                    current = current.right;
                    if (current == null) {
                        parent.right = node;
                        return;
                    }
                }
            }
        }
    }
    private int TreeLeftDepth=0;
    private int TreeRightDepth=0;
    protected boolean balancedTree=true;

    private void inOrderedTraversPrint(TreeNode current){
        if (current != null){
            inOrderedTraversPrint(current.left);
            System.out.println(current);
            inOrderedTraversPrint(current.right);
        }
    }

    private void inOrderedTravers(TreeNode current){
        if (current != null){
            inOrderedTravers(current.left);
            TreeLeftDepth+=1;
            //not necessary to calculate imbalanced tree System.out.println(current);
            inOrderedTravers(current.right);
            TreeRightDepth+=1;
        }
        else {
            if (TreeLeftDepth>6 || TreeRightDepth>6) {
                System.out.println("This is the sample of imbalanced tree. Max depth "+TreeLeftDepth+":"+TreeRightDepth);
                //To see all Tree notes (repeated numbers create imbalance) inOrderedTraversPrint(root);
                balancedTree=false;
            }
            TreeLeftDepth=0;
            TreeRightDepth=0;
        }
    }
    public void displayTreeToConsole(){
        TreeLeftDepth=0;
        TreeRightDepth=0;
        balancedTree=true;
        inOrderedTravers(root);
    }

    public TreeNoteNumber minId(){
        if (root == null) return null;
        TreeNode current = root;
        TreeNode last = null;
        while(current !=null){
            last = current;
            current = current.left;
        }
        return last.treeNoteNumber;
    }

    public TreeNoteNumber maxId(){
        if (root == null) return null;
        TreeNode current = root;
        while(current.right != null){
            current = current.right;
        }
        return current.treeNoteNumber;
    }

    public boolean delete(int id){
        TreeNode current = root;
        TreeNode parent = root;
        boolean isLeftChild = true;

        // search
        while(current.treeNoteNumber.uid != id){
            parent = current;
            if (id < current.treeNoteNumber.uid){
                current = current.left;
                isLeftChild = true;
            } else {
                current = current.right;
                isLeftChild = false;
            }

        }
        if (current == null){
            return false;
        }

        // if it is a leaf
        if (current.left == null && current.right == null){
            if (current == root)
                root = null;
            else if (isLeftChild)
                parent.left = null;
            else
                parent.right = null;
            // if only one child exist
        } else if (current.right == null){
            if (isLeftChild)
                parent.left = current.left;
            else
                parent.right =  current.left;
        } else if(current.left == null){
            if (isLeftChild)
                parent.left = current.right;
            else parent.right =  current.right;
            // if both children exist
        } else {
            TreeNode successor = getSuccessor(current);
            if (current == root)
                root = successor;
            else if (isLeftChild)
                parent.left = successor;
            else
                parent.right = successor;
            successor.left = current.left;
        }
        return true;
    }

    private TreeNode getSuccessor(TreeNode node){
        TreeNode parent = node;
        TreeNode s = node;
        TreeNode current = node.right;

        while(current != null){
            parent = s;
            s = current;
            current = current.left;
        }
        if (s!= node.right){
            parent.right = s.right;
            s.right = node.right;
        }
        return s;
    }
}
