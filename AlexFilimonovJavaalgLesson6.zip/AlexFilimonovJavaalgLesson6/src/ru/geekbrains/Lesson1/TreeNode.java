package ru.geekbrains.Lesson1;

public class TreeNode {
    TreeNoteNumber treeNoteNumber;

    public TreeNode left;
    public TreeNode right;

    public TreeNode(TreeNoteNumber treeNoteNumber) {
        this.treeNoteNumber = treeNoteNumber;
    }

    @Override
    public String toString() {
        return String.format("ID: %d; TreeNoteNumber: %d",
                treeNoteNumber.uid, treeNoteNumber.number);
    }
}
